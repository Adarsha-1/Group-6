import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {AboutComponent} from './about/about.component';
import {NewsComponent} from './news/news.component';
import { SportsNewsComponent } from "src/app/news/sportsnews";
import { FinanceNewsComponent } from "src/app/news/financenews";
import { EnquiryNewsComponent } from "src/app/news/enquirynews";

const routes: Routes = [];

@NgModule({
  imports: [RouterModule.forRoot(
    [
      {path:'about',component:AboutComponent},
      {path:'news', component:NewsComponent,
    children:[
      {path:'news/sports',component:SportsNewsComponent},
      {path:'news/finance',component:FinanceNewsComponent},
      {path:'news/enquiry',component:EnquiryNewsComponent}
    ]}
    ]
  )],
  exports: [RouterModule]
})
export class AppRoutingModule { }
