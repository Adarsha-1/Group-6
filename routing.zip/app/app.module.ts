import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AboutComponent } from './about/about.component';
import { NewsComponent } from './news/news.component';
import { SportsNewsComponent } from "src/app/news/sportsnews";
import { FinanceNewsComponent } from "src/app/news/financenews";
import { EnquiryNewsComponent } from "src/app/news/enquirynews";

@NgModule({
  declarations: [
    AppComponent,
    AboutComponent,
    NewsComponent,
    EnquiryNewsComponent,
    FinanceNewsComponent,
    SportsNewsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
