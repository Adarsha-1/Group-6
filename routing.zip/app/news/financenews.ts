import {Component} from '@angular/core';

@Component(
    {
        selector:'financecomp',
        template:`<h5>This is the area for finance news</h5>`
    }
)
export class FinanceNewsComponent
{
    
}