import {Component} from '@angular/core';

@Component(
    {
        selector:'enquirycomp',
        template:`<h5>This is the area for finance news</h5>`
    }
)
export class EnquiryNewsComponent
{
    
}