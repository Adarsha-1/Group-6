import {Component} from '@angular/core';

@Component(
    {
        selector:'sportscomp',
        template:`<h5>This is the area for sports news</h5>`
    }
)
export class SportsNewsComponent
{
    
}