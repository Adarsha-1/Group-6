export class book
{
    userId:string;
    id:string;
    title:string;
    body:string
}