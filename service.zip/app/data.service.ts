import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable, throwError} from 'rxjs';
import {Localbook} from './Localbook';
import {retry, catchError} from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class DataService {
  myData()
  {
    return 'Dataservice is implemented';
  }
  localurl:string='https://jsonplaceholder.typicode.com/posts';
  constructor(private http:HttpClient) { }
  //http headers
  httpOptions={
    headers: new HttpHeaders(
      {
        'Content-Type':'application/json'
      }
    )
  }
  //get local books
  GetLocalBooks():  Observable <Localbook>
  {
    return this.http.get<Localbook>(this.localurl).pipe(retry(1),catchError(this.errorHandl));
  }
  errorHandl(error)
  {
    let errorMessage='';
    if(error.error instanceof ErrorEvent)
    {
      errorMessage=error.error.message;
    }
    else
    {
      errorMessage='Error Code: $(error.status)\n message';
    }
    console.log("error"+errorMessage);
    return throwError;
  }

  /*data:object;
  //http post book
  PostNewBook():any
  {
    console.log("Inside PostNewBook() of data service");
    this.http.post(this.baseurl, JSON.stringify(
      {
        body:'bar',
        title:'foo',
        userId:1
      }
    ))
    .subscribe(data=>{
      this.data=data;
    });
  }*/
}
